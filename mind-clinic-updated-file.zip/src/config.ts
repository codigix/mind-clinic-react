// This file is for storing API keys and endpoints.

export const apiConfig = {
  googleSheetApiKey: 'https://script.google.com/macros/s/AKfycbxMWJ66D-qPgSEff8tiXhgnrafL_pMfk9aOVtK_4mCVBdb9TdvVgilpCeOtYEznefDsJQ/exec',
  chatbotEndpoint: 'https://insightthemindclinicrevproxy.vercel.app/api/proxy',
};